#include <stdio.h>
#include <stdlib.h>
#include "prijava_na_sistem.h"


int main()
{
    prijavaNaSistem();
    return 0;
}
