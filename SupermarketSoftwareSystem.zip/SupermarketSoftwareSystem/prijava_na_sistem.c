#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "prijava_na_sistem.h"

#define USERNAMEFORMAT_LEN 5
#define PASSWORDFORMAT_LEN 8
#define CONFIG_N 2


int birajVrstuNaloga();

NALOG unesiImeILozinku(int);
int provjeraKorisnickogImena(int, char*, FILE*);
int provjeraLozinke(int, char*, FILE*);
int ocitajBrojPrijava(int, char*, FILE*);

int nPrijava(NALOG);

int prijavaNaSistem()
{
    int vrstaNaloga = birajVrstuNaloga();
    NALOG nalog = unesiImeILozinku(vrstaNaloga);
    if(nPrijava(nalog))
    {
       // promjenaLozinke(nalog);
       printf("promjena lozinke");
    }
}

int birajVrstuNaloga(){
    int vrsta;
    printf("Izaberite vrstu naloga:\n");
    printf("1. Sef\n2. Radnik\n");
    scanf("%d", &vrsta);
    return vrsta - 1;
}

NALOG unesiImeILozinku(int vrstaNaloga){
    FILE *file;
    char korisnickoIme[NAMESIZE], lozinka[PWSIZE];
    if((file = fopen("nalozi.csv","r")) == NULL)
    {
        printf("ERROR");
        exit(1);
    }

    int ispravno = 0, brojPokusaja = 0;

    do{
        printf("Unesite korisnicko ime:\n");
        scanf("%s", korisnickoIme);
        ispravno = provjeraKorisnickogImena(vrstaNaloga, korisnickoIme, file);
        brojPokusaja++;

    }while(!ispravno && brojPokusaja<4);

    do{
        printf("Unesite lozinku:\n");
        scanf("%s", lozinka);
        ispravno = provjeraLozinke(vrstaNaloga, lozinka, file);
        brojPokusaja++;

    }while(!ispravno && brojPokusaja<4);

     int brojPrijava = ocitajBrojPrijava(vrstaNaloga, korisnickoIme, file);

     fclose(file);

     NALOG nalog;
     nalog.vrstaNaloga = vrstaNaloga;
     nalog.brojPrijava = brojPrijava;
     strncpy(nalog.korisnickoIme, korisnickoIme, NAMESIZE);
     strncpy(nalog.lozinka, lozinka, PWSIZE);

     return nalog;

}
int provjeraKorisnickogImena(int vrstaNaloga, char* korisnickoIme, FILE* file){

    if(strlen(korisnickoIme)<USERNAMEFORMAT_LEN)
    {
        printf("Prekratko korisnicko ime\n");
        return 0;
    }

    rewind(file);

    int vrstaNalogaDummy;
    char korisnickoImeDummy[NAMESIZE];
    char line[256];
    while(fgets(line, 256, file) != NULL)
    {
      sscanf(line, "%d,%s,%*s,%*d", &vrstaNalogaDummy, korisnickoImeDummy);
      if(vrstaNalogaDummy == vrstaNaloga)
      {
          if(strncmp(korisnickoIme,korisnickoImeDummy, NAMESIZE) == 0)
            return 1;
      }
    }


}
int provjeraLozinke(int vrstaNaloga, char* lozinka, FILE* file){

    if(strlen(lozinka)<PASSWORDFORMAT_LEN)
    {
        printf("Prekratka lozinka\n");
        return 0;
    }

    for(int i = 0; i< strlen(lozinka); i++)
    {
        if(isdigit(lozinka[i]))
            break;
        if(i == strlen(lozinka))
        {
            printf("Lozinka mora imati bar jedan broj");
            return 0;
        }

    }
    rewind(file);

    int vrstaNalogaDummy;
    char lozinkaDummy[PWSIZE];
    char line[256];
    while(fgets(line, 256, file) != NULL)
    {
      sscanf(line, "%d,%*s,%s,%*d", &vrstaNalogaDummy, lozinkaDummy);
      if(vrstaNalogaDummy == vrstaNaloga)
      {
          if(strncmp(lozinka,lozinkaDummy, PWSIZE) == 0)
            return 1;
      }
    }
}
int ocitajBrojPrijava(int vrstaNaloga, char* korisnickoIme, FILE* file){

    rewind(file);

    int brojPrijavaDummy;
    char korisnickoImeDummy[NAMESIZE];
    int vrstaNalogaDummy;
    char line[256];
    while(fgets(line, 256, file) != NULL)
    {
      sscanf(line, "%d,%s,%*s,%d", &vrstaNalogaDummy, korisnickoImeDummy, &brojPrijavaDummy);
      if(vrstaNalogaDummy == vrstaNaloga)
      {
          if(strncmp(korisnickoIme, korisnickoImeDummy, NAMESIZE) == 0)
            return brojPrijavaDummy;
      }
    }

}


int nPrijava(NALOG nalog){

    return nalog.brojPrijava >= CONFIG_N;

}
